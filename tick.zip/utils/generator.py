import json


print("""
#define _GNU_SOURCE
#include <dlfcn.h>
#include <stdio.h>
#include <inttypes.h>
#include <sys/types.h>
#include <unistd.h>
#include <math.h>
#include <errno.h>
#include <stddef.h>
#include <wchar.h>
#include <wctype.h>
#include <complex.h> 
#include <stdlib.h>
#include <nl_types.h>
#include <termio.h>
#include <sys/types.h>
#include <dirent.h>
#include <ftw.h>
#include <ucontext.h>
#include <setjmp.h>
#include <regex.h>
#include <sched.h>
#include <semaphore.h>
#include <signal.h>
#include <search.h>
#include <wordexp.h>
#include <fenv.h>
#include <glob.h>
#include <iconv.h>
#include <mcheck.h>
#include <malloc.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <net/if.h>
#include <sys/utsname.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <utime.h>
#include <aio.h>
#include <mntent.h>

""")


def get_ret_val(val, key):
    return val[:val.index(key + " ")]

def get_arg_list(val, key):
    return val[val.index(key + " ") + len(key):]

def get_args(val, key):
    ret_str = ""
    first_list = val.split(",")
    for elem in first_list:
        e = elem.split(" ")[-1]
        if e and e[0] == "*":
            e = e[1:]
        ret_str += e + ","
    ret_str = ret_str[:-1].replace(")","").replace("(", "").replace("*","").replace("[","").replace("]","")
    if ret_str != "void":
        return ret_str
    return ""
        
def get_args_type_list(val, key):
    ret_val = get_arg_list(val, key)
    return ret_val[2:-1]

with open('libc_functions.txt', 'r') as file:
    d = json.loads(file.read())

for key, value in d.items():
    # print(get_ret_val(value, key), get_arg_list(value, key))
    if "&hellip;" in value:
        value = value.replace("&hellip;", "...")
        if(get_ret_val(value,key) == "void "):
            s = f"""
{value}{{
    va_list ap;
    {get_ret_val(value,key)} (*original_func)({get_args_type_list(value, key)});
    original_func = dlsym(RTLD_NEXT, "{key}");
    preload_log("%s", "");
    original_func({get_args(value,key)[:-4]},ap);
    return;
}}
"""
        else:
            s = f"""
{value}{{
    va_list ap;
    {get_ret_val(value,key)} (*original_func)({get_args_type_list(value, key)});
    original_func = dlsym(RTLD_NEXT, "{key}");
    preload_log("%s", "");
    {get_ret_val(value,key)} ret_val = original_func({get_args(value,key)[:-4]},ap);
    return ret_val;
}}
"""
    else:  
        s = f"""
{value}{{
    {get_ret_val(value,key)} (*original_func)({get_args_type_list(value, key)});
    original_func = dlsym(RTLD_NEXT, "{key}");
    preload_log("%s", "");
    return original_func({get_args(value,key)});
}}
""".replace("-","_").replace("xsubi3", "xsubi")
    if key == "signbit" or "tss_t" in s or "totalorder" in s or "register_printf_function" in s or "mtx_t" in s or "thrd_" in s or key.isupper() or "cnd_t" in s or "_FloatN" in s or "_FloatNx" in s or "once_flag" in s:
        pass
    else:
        print(f"#ifndef {key}_OVERRIDE")
        print(f"#define {key}_OVERRIDE")
        print(s)
        print(f"#endif")