import requests
import re
import json

def cleanhtml(raw_html):
    cleanr = re.compile('<.*?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

functions_libc = {}

base_url = "https://www.gnu.org/software/libc/manual/html_node/"
result = requests.get("https://www.gnu.org/software/libc/manual/html_node/Function-Index.html")
for line in result.text.split("\n"):
    if "<code>" in line:
        regex_result = re.search('<code>(.*)</code>', line)
        func_name = regex_result.group(1).replace("*", "") # sometimes they put * before func name
        regex_result = re.search('</code></a>:</td><td>&nbsp;</td><td valign="top"><a href="(.*)">', line)
        link = regex_result.group(1)
        api_result = requests.get(base_url + link)
        for l in api_result.text.split("\n"):
            fname_str_html = f"<strong>{func_name}</strong>"
            if fname_str_html in l and "Macro" not in l:
                args = cleanhtml(l[l.index(fname_str_html) + len(fname_str_html):])
                regex_result = re.search('<em>(.*)</em>.*<strong>', l)
                ret_val = regex_result.group(1) + " "

                print(ret_val, func_name, args)
                functions_libc[func_name] = ret_val + func_name + args

with open('libc_functions.txt', 'w') as file:
    file.write(json.dumps(functions_libc))

# print(result.text)