#ifndef _CUSTOM_PRELOADS_H
#define _CUSTOM_PRELOADS_H


#define fork_OVERRIDE
#define waitpid_OVERRIDE
#define ptrace_OVERRIDE
#define write_OVERRIDE
#define signal_OVERRIDE

#endif